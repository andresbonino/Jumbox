package jumbox;


public enum OpcionesDeposito {
	
	Armar_Envio, Crear_Producto, Editar_Producto, Ver_Stock, Salir;
}
