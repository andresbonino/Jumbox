package jumbox;

public enum Registro {
	
	Iniciar_Sesion, Registrarse;

}
