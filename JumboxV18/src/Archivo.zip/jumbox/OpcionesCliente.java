package jumbox;


public enum OpcionesCliente {
	
	Comprar, Carrito, Editar_carrito, Mi_Compra, Salir;
}
