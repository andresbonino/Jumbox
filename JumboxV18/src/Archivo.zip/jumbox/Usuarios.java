package jumbox;


public enum Usuarios {
	
	Cliente, Encargado_Deposito, Encargado_Sucursal, Salir;
}
