package jumbox;


public enum OpcionesSucursal {

	Consultar_Productos, Gestionar_Pedidos, Salir;
}
